#!/bin/sh

aclocal
autoheader
autoconf
automake --add-missing
